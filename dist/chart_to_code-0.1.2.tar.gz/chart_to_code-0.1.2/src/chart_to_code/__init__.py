"""Top-level package for Chart to Code."""

__author__ = """Ahmad Shalaby"""
__email__ = 'ahmad.t.shalaby@gmail.com'
